


# check for NA and outlier on our variables of interest.

# Data manipulation from raw data require following packages
library(dplyr)
library(tidyr)
library(lubridate)
library(ggplot2)

load("more/citibike.RData")

str(citibike)

summary(citibike$age)

filter(citibike, is.na(age))

nrow(filter(citibike, is.na(age))) / nrow(citibike)

nrow(filter(citibike, age >= 80)) / nrow(citibike)

# sample size = 10% of total population

nrow(citibike) * 10/100

# Sample size = 5000

nrow(filter(citibike , durationminute >= 45)) / nrow(citibike)

final[complete.cases(final[,5:6]),] 


# Remove 5 rows with imcomplete age
df <- citibike[complete.cases(citibike[, "age"]),]

summary(df$age)
summary(df$durationminute)

max(df$durationminute) / 60

df2 <- filter(df, durationminute < 90000.00)
summary(df2)
max(df2$durationminute) / 60

df3 <- filter(df, durationminute >120)
dim(df3)
unique(df3)

mean(citibike$age)
mean(df$age)

mean(df_age$age)

df4 <- filter(df, durationminute <=120)
dim(df4)

df5 <- filter(citibike, age >= 88)
dim(df5)

unique(df5$age)


df_age <- filter(citibike, age < 88)

summary(df_age$age)
summary(df4)
hist(df_age$age)


hist(df4$durationminute)

hist(log(df3$durationminute +1))


# Kent Ave & S 11 St -> Brooklyn

cor.test(citibike$age, log(citibike$duration+1))

plot(log(citibike$duration + 1)~ citibike$age)

hist(citibike$age)

hist(log(citibike$durationminute + 1))

dur.log <-log(citibike$duration+1)

age<-citibike$age

lm.log.out <- lm(dur.log ~ age)

summary(lm.log.out)

####################################################

samp <- citibike[sample(nrow(citibike), 1000), ]

hist(samp$age)
hist(samp$durationminute)

#######################################3

summary(citibike)

filter(citibike, is.na(birth.year) | gender == 0)

# Remove incomplete case
citibike <- filter(citibike, !is.na(birth.year) & gender != 0)

################################################

citibike <- filter(citibike, durationminute <= 120)

################################################

citibike %>% filter(age >= 88) %>% 
             select(birth.year, age, gender, startdate, starttime2, start.station.name, durationminute) %>% 
             arrange(desc(age), startdate, starttime2)


citibike <- filter(citibike, age < 88)

#################################################  

source("http://stat.duke.edu/courses/Spring12/sta101.1/labs/inference.R")
str(samp)
samp$rideday <- as.numeric(samp$rideday)
inference(y = samp$durationminute, x = rideday, est = "mean", type = "ht", null = 0, alternative = "twosided", method = "theoretical")

inference(y = nc$weight, x = nc$habit, est = "mean", type = "ht", null = 0, alternative = "twosided", method = "theoretical")

inference(y = nc$weight, x = nc$habit, est = "mean", type = "ht", null = 0, 
          alternative = "twosided", method = "theoretical")

